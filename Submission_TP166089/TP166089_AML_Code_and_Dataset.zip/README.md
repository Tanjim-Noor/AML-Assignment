# TP166089 — Applied Machine Learning Code and Dataset

This archive accompanies the report **GPA Change Prediction from Student Context and AI-Use Patterns** by Tanjim Noor (TP166089).

## Contents

- `Code/06_comprehensive_gpa_change_regression.ipynb` — main, fully executed assignment implementation and reported results.
- `Code/07_interactive_gpa_prediction_demo.ipynb` — executed reader-facing prediction demonstration.
- `Code/Deep_Learning_Experiments/` — three executed GPU comparison notebooks (category-embedding MLP, FT-Transformer and TabM).
- `Datasets/Impact of AI on Students/ai_student_impact_dataset.csv` — unchanged raw modelling dataset.
- `requirements.txt` — core notebook environment.
- `requirements-deep-learning.txt` — optional packages for the GPU comparisons.

The dataset path is intentionally preserved because every notebook discovers it relative to the extracted archive root.

## Reproduce the main analysis

1. Extract the ZIP without changing the folder structure.
2. Create a Python environment (Python 3.13 was used for the reported run).
3. From the extracted root, install the core dependencies:

   ```text
   python -m pip install -r requirements.txt
   ```

4. Start JupyterLab from the extracted root:

   ```text
   python -m jupyter lab
   ```

5. Open and run `Code/06_comprehensive_gpa_change_regression.ipynb`, followed by notebook 07 if the interactive demonstration is required.

Notebook 06 was freshly re-executed during the final submission audit on 5 August 2026. All 26 code cells completed without a notebook error and reproduced the reported HGB test results (RMSE 0.1414 and R-squared 0.4185). Notebook 07 retains its verified widget state and worked-example output.

The deep-learning notebooks retain outputs from the documented NVIDIA RTX 3080 GPU run. Their optional environment is separate because the appropriate PyTorch build depends on the target machine and CUDA installation. Install a suitable PyTorch 2.11 build first, then use `requirements-deep-learning.txt`.

## Data integrity and interpretation

- Dataset rows: 50,000; columns: 16.
- Raw dataset SHA-256: `44ea8044236f16dc5b6ad3fb36a7de5106c68457bd621bfdea0aa3eeeec1feae`.
- `Student_ID` is excluded from modelling.
- Post-semester GPA is not used as a predictor of GPA change.
- The analysis is predictive and associational. The matched-pipeline demonstration must not be interpreted as an estimated causal effect of AI use.

The dataset is Kaggle-provided and has undocumented collection and real-versus-synthetic provenance; conclusions therefore do not claim population-wide generalisability.
